---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯粉
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
categories:
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# 福鲁伊克斯粉

<ItemImage id="fluix_dust" scale="4" />

被<ItemLink id="inscriber" />粉碎的<ItemLink id="fluix_crystal" />。用于制造部分AE2机器和组件。

## 配方

<RecipeFor id="fluix_dust" />
